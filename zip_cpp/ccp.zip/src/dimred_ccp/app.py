# Aquí va la lógica de Streamlit (ver respuesta larga)
